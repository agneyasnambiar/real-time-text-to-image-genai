# Task 1 - BERT Tokenization and Embedding using Hugging Face Transformers

## Objective
The goal of this task is to:
- Use a pre-trained BERT model from Hugging Face Transformers.
- Perform **tokenization** (splitting text into sub-word tokens).
- **Encode** the tokens into input IDs and attention masks.
- Pass the encoded inputs into BERT to extract embeddings from the model's final hidden state.

## Model
- Model used: `bert-base-uncased` from HuggingFace Transformers.

## Code Overview
import sys
!{sys.executable} -m pip install transformers torch
!pip install huggingface_hub[hf_xet]

from transformers import BertTokenizer, BertModel
import torch
tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
model = BertModel.from_pretrained('bert-base-uncased')
text = "Hello, my name is Agneya and I am doing internship with Nullclass"

# Step 1: Tokenization (splitting into tokens)
tokens = tokenizer.tokenize(text)
print("Tokens:")
print(tokens)

# Step 2: Encoding (tokens → input IDs + tensors)
encoding = tokenizer(text, return_tensors='pt')
print("\nInput IDs:")
print(encoding['input_ids'])
print("Attention Mask:")
print(encoding['attention_mask'])

# Step 3: Use BERT to get embeddings
with torch.no_grad():
    outputs = model(**encoding)
print("\nOutput Embeddings Shape (last_hidden_state):")
print(outputs.last_hidden_state.shape)

### Required Libraries
```python
import sys
!{sys.executable} -m pip install transformers torch
!pip install huggingface_hub[hf_xet]


#Objective
Accuracy is not directly applicable, but model is functioning as expected.

##Author
Agneya S Nambiar

📁 Google drive: https://drive.google.com/drive/folders/141KH_7mM3f59ROKyaE6vvIYIwyMQUatE?usp=sharing
