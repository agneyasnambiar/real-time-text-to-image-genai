# Task 2 - Dataset Analysis Report
Dataset: Oxford 102 Flowers (via tensorflow_datasets)
# Project Overview
This project explores the Oxford Flowers 102 public dataset using TensorFlow Datasets (TFDS). The goal is to understand the dataset structure, analyze image resolution statistics, visualize sample images with their class labels, and save key visualizations and statistics for reporting.
# Analysis Summary:
Number of Classes: 102 flower species
Sample Image Resolution (based on 100 samples):
  - Mean Height: ~500px
  - Mean Width: ~500px
Text Description Lengths(based on 100 samples):
  - Min: ~7 words
  - Max: ~23 words
  - Average: ~14.3 words
Visualizations: A 3x3 grid of sample images with their truncated captions is displayed.
# Tools Used:
- TensorFlow Datasets (tfds)
- Matplotlib
- Pandas
- NumPy
# What this project does:
- Loads the dataset using TFDS with supervised labels
- Prints dataset info: number of classes, total examples per split
- Analyzes and summarizes image resolution statistics (height and width) for 200/100 samples
- Saves image resolution statistics as a CSV file
- Visualizes and saves boxplot of image size distribution
- Displays and saves sample flower images with their class names (3x3 grid)
- Saves all visuals in the `images_and_statistics/` folder
# Folder Structure:
- `dataset_analysis-agneya.ipynb`: Complete code for data loading and analysis
- `README.md`: Summary and notes
